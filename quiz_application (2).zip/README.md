# QuizHub - JavaScript + Bootstrap

## Features
- Student and Admin roles
- Separate Sign Up / Login
- Student can take multiple-choice quizzes
- Score/result screen
- Admin can add and delete questions
- Bootstrap responsive UI
- CSS animations and glass-style cards
- Uses localStorage, so no backend/database is required

## How to run
1. Extract the ZIP.
2. Open `index.html` in Chrome/Edge.
3. Sign up as Student or Admin.
4. Admin can add questions from the Admin Dashboard.
5. Student can login and take the quiz.

### Demo flow
Admin -> Sign Up -> Login -> Add/Delete Questions
Student -> Sign Up -> Login -> Start Quiz -> View Score

Note: This is a frontend demo. Passwords are stored in browser localStorage, so it is not suitable for real production authentication.
