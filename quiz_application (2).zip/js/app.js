const defaultQuestions=[
 {id:1,q:"Which language runs in a web browser?",options:["Java","C","JavaScript","Python"],answer:2},
 {id:2,q:"Which Bootstrap class creates a primary button?",options:["btn-main","btn-primary","button-blue","primary-btn"],answer:1},
 {id:3,q:"What does DOM stand for?",options:["Document Object Model","Data Object Method","Digital Ordinance Mode","Document Order Map"],answer:0},
 {id:4,q:"Which keyword declares a constant in JavaScript?",options:["let","var","constant","const"],answer:3}
];
let questions=JSON.parse(localStorage.getItem("questions"))||defaultQuestions;
let users=JSON.parse(localStorage.getItem("users"))||[];
let currentUser=null,currentQuestions=[],qIndex=0,score=0,selected=null,authMode="signup";

function save(){localStorage.setItem("questions",JSON.stringify(questions));localStorage.setItem("users",JSON.stringify(users))}
function showView(id){document.querySelectorAll("main section").forEach(x=>x.classList.add("d-none"));document.getElementById(id).classList.remove("d-none");window.scrollTo({top:0,behavior:"smooth"})}
function showAuth(mode){authMode=mode;document.getElementById("authTitle").textContent=mode==="signup"?"Create Account":"Welcome Back";document.getElementById("authSubmit").textContent=mode==="signup"?"Create Account":"Login";document.getElementById("nameGroup").classList.toggle("d-none",mode==="login");document.getElementById("switchAuth").textContent=mode==="signup"?"Already have an account? Login":"New here? Create account";showView("authView")}
document.getElementById("switchAuth").onclick=()=>showAuth(authMode==="signup"?"login":"signup");

document.getElementById("authForm").onsubmit=e=>{
 e.preventDefault();let name=document.getElementById("name").value.trim(),email=document.getElementById("email").value.trim().toLowerCase(),password=document.getElementById("password").value,role=document.getElementById("role").value;
 if(authMode==="signup"){if(users.some(u=>u.email===email)){alert("Email already registered.");return}users.push({name:name||"User",email,password,role});save();alert("Account created. Please login.");showAuth("login")}
 else{let u=users.find(x=>x.email===email&&x.password===password&&x.role===role);if(!u){alert("Invalid email, password, or role.");return}login(u)}
};
function login(u){currentUser=u;document.getElementById("navUser").textContent=`Hi, ${u.name} (${u.role})`;document.getElementById("logoutBtn").classList.remove("d-none");if(u.role==="admin"){showView("adminView");renderAdmin()}else{showView("studentView");renderQuizzes()}}
document.getElementById("logoutBtn").onclick=()=>{currentUser=null;document.getElementById("logoutBtn").classList.add("d-none");document.getElementById("navUser").textContent="";showView("homeView")};

function renderQuizzes(){let list=document.getElementById("quizList");list.innerHTML=`<div class="col-md-6 col-lg-4"><div class="card quiz-card p-4 h-100"><div class="fs-1">🧠</div><h4>General Web Quiz</h4><p class="text-secondary">${questions.length} questions • Multiple choice</p><button class="btn btn-primary mt-auto" onclick="startQuiz()">Start Quiz</button></div></div>`}
function startQuiz(){currentQuestions=[...questions];qIndex=0;score=0;selected=null;showView("quizView");renderQuestion()}
function renderQuestion(){let q=currentQuestions[qIndex];document.getElementById("quizTitle").textContent="General Web Quiz";document.getElementById("progressText").textContent=`${qIndex+1}/${currentQuestions.length}`;document.getElementById("progressBar").style.width=((qIndex)/currentQuestions.length*100)+"%";document.getElementById("questionText").textContent=q.q;let box=document.getElementById("options");box.innerHTML="";q.options.forEach((o,i)=>{let b=document.createElement("button");b.className="option-btn";b.textContent=String.fromCharCode(65+i)+". "+o;b.onclick=()=>{selected=i;document.querySelectorAll(".option-btn").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");document.getElementById("nextBtn").disabled=false};box.appendChild(b)});document.getElementById("nextBtn").textContent=qIndex===currentQuestions.length-1?"Finish":"Next";document.getElementById("nextBtn").disabled=true}
function nextQuestion(){if(selected===currentQuestions[qIndex].answer)score++;if(qIndex<currentQuestions.length-1){qIndex++;selected=null;renderQuestion()}else{document.getElementById("progressBar").style.width="100%";document.getElementById("resultText").textContent=`You scored ${score} out of ${currentQuestions.length}.`;document.getElementById("studentScore").textContent=`Last Score: ${score}/${currentQuestions.length}`;showView("resultView")}}
function exitQuiz(){showView("studentView");renderQuizzes()}

function renderAdmin(){let box=document.getElementById("adminQuestions");if(!questions.length){box.innerHTML="<p>No questions yet.</p>";return}box.innerHTML=questions.map((q,i)=>`<div class="border rounded-4 p-3 mb-3"><div class="d-flex justify-content-between gap-2"><strong>${i+1}. ${q.q}</strong><button class="btn btn-sm btn-outline-danger" onclick="deleteQuestion(${q.id})">Delete</button></div><ol class="mt-2 mb-0">${q.options.map((o,j)=>`<li class="${j===q.answer?"fw-bold text-primary":""}">${o}</li>`).join("")}</ol></div>`).join("")}
function openQuestionModal(){document.getElementById("questionForm").reset();new bootstrap.Modal("#questionModal").show()}
document.getElementById("questionForm").onsubmit=e=>{e.preventDefault();questions.push({id:Date.now(),q:qText.value,options:[qA.value,qB.value,qC.value,qD.value],answer:+qAnswer.value});save();bootstrap.Modal.getInstance(document.getElementById("questionModal")).hide();renderAdmin()}
function deleteQuestion(id){questions=questions.filter(q=>q.id!==id);save();renderAdmin()}
